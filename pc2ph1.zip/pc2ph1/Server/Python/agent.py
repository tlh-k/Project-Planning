import os
import sys
import time
import json
import uuid
import hashlib
import asyncio
import socket
import logging
import argparse
import uvicorn
import netifaces
import pyperclip
import aiofiles
from typing import List, Optional
from threading import Thread
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect, Body, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
from pydantic import BaseModel
from zeroconf import ServiceInfo, Zeroconf

# --- Configuration ---
PORT = 8080
SERVICE_TYPE = "_antigrav._tcp.local."
DEVICE_NAME = socket.gethostname()
UPLOAD_DIR = Path("received_files")
UPLOAD_DIR.mkdir(exist_ok=True)

# --- Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("AntigravityAgent")

# --- FastAPI App ---
app = FastAPI(title="Antigravity Sync Agent")

# --- Globals ---
active_websockets: List[WebSocket] = []
zeroconf: Optional[Zeroconf] = None

# --- Models ---
class InitTransferRequest(BaseModel):
    fileName: str
    size: int
    mimeType: str
    hash: str

class TextPayload(BaseModel):
    content: str
    isAutoCopy: bool = True

class FileOffer(BaseModel):
    id: str
    type: str = "file"
    timestamp: float
    payload: dict

# --- Utils ---
def get_local_ip():
    try:
        # Try to find the primary IP
        gw = netifaces.gateways()
        default = gw.get('default', {}).get(netifaces.AF_INET)
        if default:
            iface = default[1]
            return netifaces.ifaddresses(iface)[netifaces.AF_INET][0]['addr']
        return "127.0.0.1"
    except:
        return "127.0.0.1"

def calculate_hash(file_path: Path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.hexdigest()

# --- Discovery (mDNS) ---
def register_service():
    global zeroconf
    ip_address = get_local_ip()
    logger.info(f"Registering mDNS service on {ip_address}:{PORT}")
    
    desc = {'api_version': '1.0', 'device_name': DEVICE_NAME}
    
    info = ServiceInfo(
        SERVICE_TYPE,
        f"Antigravity-{DEVICE_NAME}.{SERVICE_TYPE}",
        addresses=[socket.inet_aton(ip_address)],
        port=PORT,
        properties=desc,
        server=f"{DEVICE_NAME}.local.",
    )
    
    zeroconf = Zeroconf()
    zeroconf.register_service(info)

def unregister_service():
    if zeroconf:
        zeroconf.close()

# --- API Endpoints (iOS -> PC Upload) ---

@app.get("/")
def get_dashboard():
    ip = get_local_ip()
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Antigravity Agent</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {{ font-family: -apple-system, system-ui, sans-serif; text-align: center; padding: 50px; background: #f0f2f5; }}
            .card {{ background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); max-width: 400px; margin: auto; }}
            h1 {{ color: #007aff; margin-bottom: 10px; }}
            .status {{ color: #34c759; font-weight: bold; font-size: 1.2em; }}
            .info {{ color: #666; margin-top: 20px; font-size: 0.9em; }}
            code {{ background: #eee; padding: 4px 8px; border-radius: 4px; }}
        </style>
    </head>
    <body>
        <div class="card">
            <h1>Antigravity Sync</h1>
            <p>Desktop Agent is <span class="status">Online</span></p>
            <div class="info">
                <p>Device Name: <strong>{DEVICE_NAME}</strong></p>
                <p>IP Address: <code>{ip}:{PORT}</code></p>
                <p>Open iOS App to Connect</p>
            </div>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content, status_code=200)

@app.get("/status")
def get_status():
    return {"online": True, "device_name": DEVICE_NAME}

@app.get("/handshake")
def handshake(device_id: str):
    logger.info(f"Handshake requested by {device_id}")
    return {"status": "paired", "token": "dummy-token-123"}

@app.post("/transfer/init")
def init_transfer(req: InitTransferRequest):
    transfer_id = str(uuid.uuid4())
    logger.info(f"Initializing transfer for {req.fileName} ({req.size} bytes)")
    
    # Store metadata for verification later (In memory for MVP)
    app.state.pending_transfers = getattr(app.state, "pending_transfers", {})
    app.state.pending_transfers[transfer_id] = req
    
    return {"transfer_id": transfer_id, "approved": True, "max_chunk_size": 10 * 1024 * 1024}

@app.put("/transfer/upload/{transfer_id}")
async def upload_chunk(transfer_id: str, request: Request):
    # Streaming write
    file_path = UPLOAD_DIR / f"temp_{transfer_id}"
    
    async with aiofiles.open(file_path, mode="ab") as f:
        async for chunk in request.stream():
            await f.write(chunk)
            
    return {"status": "chunk_received"}

@app.post("/transfer/finalize/{transfer_id}")
async def finalize_transfer(transfer_id: str):
    meta = getattr(app.state, "pending_transfers", {}).get(transfer_id)
    if not meta:
        raise HTTPException(status_code=404, detail="Transfer not found")
        
    temp_path = UPLOAD_DIR / f"temp_{transfer_id}"
    if not temp_path.exists():
        raise HTTPException(status_code=400, detail="Data missing")
        
    # Verify Hash
    logger.info("Verifying hash...")
    calculated_hash = calculate_hash(temp_path)
    if calculated_hash != meta.hash:
        logger.error(f"Hash mismatch! Expected {meta.hash}, got {calculated_hash}")
        temp_path.unlink()
        raise HTTPException(status_code=400, detail="Integrity Check Failed")
        
    # Move to final
    final_path = UPLOAD_DIR / meta.fileName
    if final_path.exists():
        final_path.unlink()
    temp_path.rename(final_path)
    
    logger.info(f"File saved: {final_path}")
    return {"status": "completed", "path": str(final_path)}

@app.post("/transfer/text")
def receive_text(payload: TextPayload):
    logger.info(f"Received text: {payload.content}")
    try:
        pyperclip.copy(payload.content)
    except Exception as e:
        logger.warning(f"Clipboard error (headless?): {e}")
    return {"status": "copied"}

# --- WebSocket & Outgoing Features (PC -> iOS) ---

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_websockets.append(websocket)
    try:
        while True:
            await websocket.receive_text() # Keep alive
    except WebSocketDisconnect:
        active_websockets.remove(websocket)

async def broadcast_text(text: str):
    payload = {
        "id": str(uuid.uuid4()),
        "type": "text",
        "timestamp": time.time(),
        "payload": {
            "content": text,
            "isAutoCopy": True
        }
    }
    for ws in active_websockets:
        await ws.send_json(payload)

async def broadcast_file(file_path: Path):
    if not file_path.exists():
        logger.error("File not found")
        return

    # Calculate Request
    size = file_path.stat().st_size
    file_hash = calculate_hash(file_path)
    ip = get_local_ip()
    url = f"http://{ip}:{PORT}/files/{file_path.name}"
    
    payload = {
        "id": str(uuid.uuid4()),
        "type": "file",
        "timestamp": time.time(),
        "payload": {
            "fileName": file_path.name,
            "fileExtension": file_path.suffix.replace(".", ""),
            "mimeType": "application/octet-stream", # simplified
            "size": size,
            "hash": file_hash,
            "downloadUrl": url
        }
    }
    
    logger.info(f"Offering file: {file_path.name} ({url})")
    for ws in active_websockets:
        await ws.send_json(payload)

# Serve files for download
@app.get("/files/{filename}")
async def serve_file(filename: str):
    path = Path.cwd() / filename 
    if path.exists():
        return FileResponse(path)
    
    path_upload = UPLOAD_DIR / filename
    if path_upload.exists():
        return FileResponse(path_upload)
        
    raise HTTPException(404)

# --- Clipboard Monitor ---
import subprocess
import urllib.parse

def get_clipboard_files():
    """
    Attempts to get file paths from the Linux clipboard using xclip.
    Returns a list of absolute file paths (Path objects).
    """
    try:
        # Check for gnome-copied-files (Nautilus/standard Linux file copy)
        result = subprocess.run(
            ['xclip', '-selection', 'clipboard', '-o', '-t', 'x-special/gnome-copied-files'],
            capture_output=True, text=True, timeout=1
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            action = lines[0] # usually 'copy' or 'cut'
            paths = []
            for line in lines[1:]:
                if line.startswith('file://'):
                    # specific decoding needed for file:// URIs
                    decoded_path = urllib.parse.unquote(line[7:]).strip()
                    paths.append(Path(decoded_path))
            return paths
    except Exception:
        pass
    return []

def clipboard_monitor_loop():
    logger.info("Clipboard Watcher started...")
    last_text = ""
    last_files = []
    
    # Main loop for the thread
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    while True:
        try:
            # 1. Check Text
            text = ""
            try:
                text = pyperclip.paste()
            except: 
                pass
                
            if text and text != last_text:
                last_text = text
                # If valid file path is in text, treat as file? No, pyperclip usually gets text representation.
                # Prioritize text content if regular copy
                logger.info(f"Clipboard text changed ({len(text)} chars). Broadcasting...")
                loop.run_until_complete(broadcast_text(text))
            
            # 2. Check Files (Linux specific)
            current_files = get_clipboard_files()
            if current_files and current_files != last_files:
                last_files = current_files
                for file_path in current_files:
                    if file_path.exists() and file_path.is_file():
                        logger.info(f"Clipboard file detected: {file_path}")
                        loop.run_until_complete(broadcast_file(file_path))
                        
        except Exception as e:
            # Only log error once to avoid spamming
            if "not-implemented-error" in str(e) or "copy/paste mechanism" in str(e):
                if not getattr(clipboard_monitor_loop, "logged_error", False):
                    logger.error(f"Clipboard not available: Install 'xclip' (sudo apt install xclip).")
                    clipboard_monitor_loop.logged_error = True
            else:
                logger.error(f"Clipboard error: {e}")
        time.sleep(1)

# --- Main & CLI ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Antigravity Desktop Agent")
    parser.add_argument("--cli", action="store_true", help="Run in CLI mode to send commands")
    
    args = parser.parse_args()
    
    if not args.cli:
        ip = get_local_ip()
        print(f"Starting Server on {ip}:{PORT}...")
        
        # Start Clipboard Monitor in background thread
        t = Thread(target=clipboard_monitor_loop, daemon=True)
        t.start()
        
        register_service()
        try:
            uvicorn.run(app, host="0.0.0.0", port=PORT)
        finally:
            unregister_service()
