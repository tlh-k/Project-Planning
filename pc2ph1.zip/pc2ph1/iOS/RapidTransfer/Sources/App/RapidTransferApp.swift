import SwiftUI

@main
struct RapidTransferApp: App {
    let environment = AppEnvironment.shared
    
    var body: some Scene {
        WindowGroup {
            DashboardView(viewModel: environment.makeTransferViewModel())
        }
    }
}
