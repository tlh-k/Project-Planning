import Foundation

class AppEnvironment {
    static let shared = AppEnvironment()
    
    let storageManager: StorageManager
    let networkManager: NetworkManager
    
    init() {
        self.storageManager = StorageManager.shared
        self.networkManager = NetworkManager()
    }
    
    @MainActor
    func makeTransferViewModel() -> TransferViewModel {
        return TransferViewModel(transferService: networkManager, storageManager: storageManager)
    }
}
