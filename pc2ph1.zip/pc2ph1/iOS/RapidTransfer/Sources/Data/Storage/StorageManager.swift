import Foundation

class StorageManager {
    static let shared = StorageManager()
    
    private let fileManager = FileManager.default
    
    private var documentsDirectory: URL {
        fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func saveFile(data: Data, fileName: String) throws -> URL {
        let destinationURL = documentsDirectory.appendingPathComponent(fileName)
        
        // Use FileCoordinator for safe concurrent access
        let coordinator = NSFileCoordinator()
        var error: NSError?
        var resultingURL: URL?
        
        coordinator.coordinate(writingItemAt: destinationURL, options: .forReplacing, error: &error) { url in
            do {
                try data.write(to: url)
                resultingURL = url
            } catch let writeError {
                print("Error writing file: \(writeError)")
            }
        }
        
        if let error = error {
            throw error
        }
        
        guard let url = resultingURL else {
            throw NSError(domain: "StorageManager", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to save file"])
        }
        
        return url
    }
    
    func appendChunk(to fileName: String, data: Data) throws {
        let destinationURL = documentsDirectory.appendingPathComponent(fileName)
        
        if !fileManager.fileExists(atPath: destinationURL.path) {
            fileManager.createFile(atPath: destinationURL.path, contents: nil)
        }
        
        let fileHandle = try FileHandle(forWritingTo: destinationURL)
        fileHandle.seekToEndOfFile()
        fileHandle.write(data)
        fileHandle.closeFile()
    }
    
    func getFileSize(fileName: String) -> Int64? {
        let url = documentsDirectory.appendingPathComponent(fileName)
        guard let attrs = try? fileManager.attributesOfItem(atPath: url.path) else { return nil }
        return attrs[.size] as? Int64
    }
    
    // MARK: - Advanced Features
    
    /// Checks if device has enough storage space
    func checkDiskSpace(requiredBytes: Int64) -> Bool {
        guard let attributes = try? fileManager.attributesOfFileSystem(forPath: documentsDirectory.path),
              let freeSize = attributes[.systemFreeSize] as? Int64 else {
            return false
        }
        return freeSize > requiredBytes
    }
    
    /// Moves a file from a temporary location to the Documents directory
    func moveTempFile(at tempURL: URL, to fileName: String) throws -> URL {
        let destinationURL = documentsDirectory.appendingPathComponent(fileName)
        
        if fileManager.fileExists(atPath: destinationURL.path) {
            try fileManager.removeItem(at: destinationURL)
        }
        
        try fileManager.moveItem(at: tempURL, to: destinationURL)
        return destinationURL
    }
    
    /// Deletes a file at the given URL
    func deleteFile(at url: URL) {
        try? fileManager.removeItem(at: url)
    }

