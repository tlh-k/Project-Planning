import Foundation
import Network
import Combine

enum NetworkError: Error {
    case invalidURL
    case serverError(Int)
    case decodingError
    case unknown
}

class NetworkManager: NSObject, TransferServiceProtocol, ObservableObject {
    private let session: URLSession
    @Published var baseURL: URL?
    @Published var isOnline: Bool = false
    
    // Discovery
    private var browser: NWBrowser?
    let availableServices = CurrentValueSubject<Set<String>, Never>([])
    
    override init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 300
        self.session = URLSession(configuration: config)
        super.init()
        startDiscovery()
    }
    
    private func startDiscovery() {
        let descriptor = NWBrowser.Descriptor.bonjour(type: "_antigrav._tcp", domain: "local.")
        let browser = NWBrowser(for: descriptor, using: .tcp)
        
        browser.stateUpdateHandler = { newState in
            print("Browser state: \(newState)")
        }
        
        browser.browseResultsChangedHandler = { [weak self] results, changes in
            var names = Set<String>()
            for result in results {
                if case let .service(name, type, domain, interface) = result.endpoint {
                    names.insert(name)
                }
            }
            self?.availableServices.send(names)
        }
        
        browser.start(queue: .main)
        self.browser = browser
    }
    
    // For manual override
    func setBaseURL(_ url: URL) {
        self.baseURL = url
        self.isOnline = true
        connectWebSocket()
    }
    
    // Wrapper to safely get URL
    private func getURL() throws -> URL {
        // Fallback for testing protocol
        return baseURL ?? URL(string: "http://127.0.0.1:8080")!
    }

    
    struct ServerStatus: Codable {
        let online: Bool
        let device_name: String
    }

    func fetchServerStatus() async throws -> String {
        let url = try getURL().appendingPathComponent("status")
        let (data, response) = try await session.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.serverError((response as? HTTPURLResponse)?.statusCode ?? 500)
        }
        
        let status = try JSONDecoder().decode(ServerStatus.self, from: data)
        return status.device_name
    }
    
    func initTransfer(fileName: String, size: Int64, mimeType: String, hash: String) async throws -> String {
        let url = try getURL().appendingPathComponent("transfer/init")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "fileName": fileName,
            "size": size,
            "mimeType": mimeType,
            "hash": hash
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.serverError((response as? HTTPURLResponse)?.statusCode ?? 500)
        }
        
        let decoded = try JSONDecoder().decode(TransferInitResponse.self, from: data)
        return decoded.transferId
    }
    
    func uploadData(transferId: String, data: Data, isLastChunk: Bool) async throws {
        let url = try getURL().appendingPathComponent("transfer/upload/\(transferId)")
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        
        // Setup chunked encoding if needed, though URLSession handles 'Upload' tasks efficiently
        // For strict chunked encoding manually:
        // request.setValue("chunked", forHTTPHeaderField: "Transfer-Encoding")
        
        let (_, response) = try await session.upload(for: request, from: data)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.serverError((response as? HTTPURLResponse)?.statusCode ?? 500)
        }
    }
    
    func finalizeTransfer(transferId: String) async throws -> Bool {
        let url = try getURL().appendingPathComponent("transfer/finalize/\(transferId)")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let (_, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else { return false }
        
        if httpResponse.statusCode == 200 {
            return true
        } else {
            throw NetworkError.serverError(httpResponse.statusCode)
        }
    }
    
    func sendText(content: String, isAutoCopy: Bool) async throws {
        let url = try getURL().appendingPathComponent("transfer/text")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "content": content,
            "isAutoCopy": isAutoCopy
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (_, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NetworkError.serverError((response as? HTTPURLResponse)?.statusCode ?? 500)
        }
    }
    
    // MARK: - Download (Smart File Transfer)
    
    // MARK: - WebSocket (Real-time Sync)
    
    private var webSocketTask: URLSessionWebSocketTask?
    let incomingPayload = PassthroughSubject<Any, Never>() // Using Any for MVP, ideally strict types
    
    private func connectWebSocket() {
        guard let url = try? getURL() else { return }
        
        // Convert http -> ws
        var wsUrlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false)
        wsUrlComponents?.scheme = "ws"
        wsUrlComponents?.path = "/ws"
        
        guard let wsUrl = wsUrlComponents?.url else { return }
        
        print("Connecting WebSocket: \(wsUrl)")
        webSocketTask = session.webSocketTask(with: wsUrl)
        webSocketTask?.resume()
        
        listenForWebSocketMessages()
    }
    
    private func listenForWebSocketMessages() {
        webSocketTask?.receive { [weak self] result in
            switch result {
            case .failure(let error):
                print("WebSocket error: \(error)")
                // Simple reconnect logic could go here
            case .success(let message):
                switch message {
                case .string(let text):
                    self?.handleWebSocketMessage(text)
                case .data(let data):
                    print("Received binary data: \(data.count) bytes")
                @unknown default:
                    break
                }
                // Continue listening
                self?.listenForWebSocketMessages()
            }
        }
    }
    
    private func handleWebSocketMessage(_ text: String) {
        guard let data = text.data(using: .utf8) else { return }
        
        // Parse "type": "text" or "file"
        // Simplified JSON parsing for MVP
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let type = json["type"] as? String,
           let payload = json["payload"] as? [String: Any] {
            
            DispatchQueue.main.async {
                if type == "text" {
                    if let content = payload["content"] as? String {
                        self.incomingPayload.send(TextPayload(content: content, isAutoCopy: true))
                    }
                } else if type == "file" {
                   if let fileName = payload["fileName"] as? String,
                      let size = payload["size"] as? Int64,
                      let downloadUrl = payload["downloadUrl"] as? String {
                       
                       let filePayload = FilePayload(
                           fileName: fileName,
                           fileExtension: (fileName as NSString).pathExtension,
                           mimeType: payload["mimeType"] as? String ?? "application/octet-stream",
                           size: size,
                           hash: payload["hash"] as? String ?? "",
                           downloadUrl: downloadUrl
                       )
                       self.incomingPayload.send(filePayload)
                   }
                }
            }
        }
    }
    
    // MARK: - Download (Smart File Transfer)
    
    func downloadFile(url: URL) async throws -> URL {
        // Simple downloadTask wrapper (Streams to temp file automatically)
        let (tempUrl, response) = try await session.download(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.serverError((response as? HTTPURLResponse)?.statusCode ?? 500)
        }
        
        return tempUrl
    }
}
