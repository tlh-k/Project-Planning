import Foundation
import Combine
import UIKit

enum TransferState: Equatable {
    case idle
    case handshake
    case transferring(Double) // 0.0 to 1.0 progress
    case verifying
    case completed
    case error(String)
}

@MainActor
class TransferViewModel: ObservableObject {
    @Published var state: TransferState = .idle
    @Published var statusMessage: String = "Ready"
    @Published var connectedDeviceName: String?
    @Published var discoveredServers: [String] = []
    
    private let transferService: TransferServiceProtocol
    private let storageManager: StorageManager
    
    init(transferService: TransferServiceProtocol, storageManager: StorageManager) {
        self.transferService = transferService
        self.storageManager = storageManager
        
        // Subscribe to events
        if let netManager = transferService as? NetworkManager {
            netManager.incomingPayload
                .receive(on: DispatchQueue.main)
                .sink { [weak self] payload in
                    if let textPayload = payload as? TextPayload {
                        self?.simulateReceivingText(payload: textPayload)
                    } else if let filePayload = payload as? FilePayload {
                        self?.simulateReceivingFileOffer(payload: filePayload)
                    }
                }
                .store(in: &cancellables)
                
            netManager.availableServices
                .receive(on: DispatchQueue.main)
                .sink { [weak self] services in
                    self?.discoveredServers = Array(services).sorted()
                }
                .store(in: &cancellables)
        }
    }
    
    private var cancellables = Set<AnyCancellable>()
    
    func connectTo(serverName: String) {
        let hostName = serverName.replacingOccurrences(of: "Antigravity-", with: "") + ".local"
        let urlString = "http://\(hostName):8080"
        
        if let url = URL(string: urlString) {
             connectManually(url: url)
        }
    }
    
    func connectManually(url: URL) {
        if let netManager = transferService as? NetworkManager {
            netManager.setBaseURL(url)
            statusMessage = "Connecting..."
            
            Task {
                do {
                    let name = try await netManager.fetchServerStatus()
                    await MainActor.run {
                        self.connectedDeviceName = name
                        self.statusMessage = "Connected to \(name)"
                    }
                } catch {
                    await MainActor.run {
                        self.statusMessage = "Connection failed: \(error.localizedDescription)"
                    }
                }
            }
        }
    }
    
    func sendText(text: String) {
        Task {
            state = .transferring(0.0)
            do {
                try await transferService.sendText(content: text, isAutoCopy: true)
                state = .completed
                statusMessage = "Text sent successfully!"
                addToHistory(title: "Sent Text", detail: text)
            } catch {
                state = .error(error.localizedDescription)
                statusMessage = "Failed to send text."
            }
        }
    }
    
    // MARK: - Incoming Features
    
    /// Scenario 1: Instant Text Sync
    func simulateReceivingText(payload: TextPayload) {
        // On Main Actor
        if payload.isAutoCopy {
            UIPasteboard.general.string = payload.content
        }
        
        // Haptic Feedback
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        
        statusMessage = "Text copied to clipboard!"
        state = .completed
        addToHistory(title: "Received Text", detail: payload.content, type: .text)
    }
    
    /// Scenario 2: Smart File Transfer
    func simulateReceivingFileOffer(payload: FilePayload) {
        // Just add to history as an "Offer"
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        
        if let urlString = payload.downloadUrl, let url = URL(string: urlString) {
            addToHistory(
                title: "File Offer: \(payload.fileName)",
                detail: "\(payload.size / 1024) KB - Ready to download",
                type: .file,
                downloadUrl: url,
                fileName: payload.fileName
            )
            statusMessage = "File Ready: \(payload.fileName)"
        }
    }
    
    // MARK: - History
    struct HistoryItem: Identifiable {
        let id = UUID()
        let timestamp = Date()
        let title: String
        let detail: String
        
        // Extended properties
        let type: ItemType
        let downloadUrl: URL?
        let fileName: String?
        
        enum ItemType {
            case text
            case file
        }
    }
    
    @Published var history: [HistoryItem] = []
    
    private func addToHistory(title: String, detail: String, type: HistoryItem.ItemType = .text, downloadUrl: URL? = nil, fileName: String? = nil) {
        let item = HistoryItem(title: title, detail: detail, type: type, downloadUrl: downloadUrl, fileName: fileName)
        history.insert(item, at: 0)
    }
    
    func deleteHistory(at offsets: IndexSet) {
        history.remove(atOffsets: offsets)
    }
    
    func clearHistory() {
        history.removeAll()
    }
    
    // MARK: - Actions
    
    func downloadHistoryItem(_ item: HistoryItem) {
        guard let url = item.downloadUrl, let fileName = item.fileName else { return }
        
        Task {
            state = .transferring(0.0)
            statusMessage = "Downloading \(fileName)..."
            
            do {
                 if let netManager = transferService as? NetworkManager {
                     let tempUrl = try await netManager.downloadFile(url: url)
                     let savedUrl = try storageManager.moveTempFile(at: tempUrl, to: fileName)
                     
                     await MainActor.run {
                         state = .completed
                         statusMessage = "Saved to Files: \(fileName)"
                         
                         // Optional: Share Sheet could be triggered here
                     }
                 }
            } catch {
                await MainActor.run {
                    state = .error("Download failed: \(error.localizedDescription)")
                }
            }
        }
    }

    func uploadFile(fileUrl: URL) {
        Task {
            state = .handshake
            statusMessage = "Initiating transfer..."
            
            do {
                // 1. Prepare Metadata
                let resources = try fileUrl.resourceValues(forKeys: [.fileSizeKey, .nameKey])
                let fileName = resources.name ?? fileUrl.lastPathComponent
                let size = Int64(resources.fileSize ?? 0)
                let hash = "sha256-placeholder" 
                
                // 2. Pre-flight
                let transferId = try await transferService.initTransfer(fileName: fileName, size: size, mimeType: "application/octet-stream", hash: hash)
                
                // 3. Upload (Chunked logic simplified for MVP)
                state = .transferring(0.0)
                let data = try Data(contentsOf: fileUrl) // WARNING: Loading full file into memory. In Prod, use FileHandle for chunks.
                
                // 3.1 Send Data
                try await transferService.uploadData(transferId: transferId, data: data, isLastChunk: true)
                state = .transferring(1.0)
                
                // 4. Finalize
                state = .verifying
                statusMessage = "Verifying integrity..."
                let success = try await transferService.finalizeTransfer(transferId: transferId)
                
                if success {
                    state = .completed
                    statusMessage = "Transfer complete!"
                    addToHistory(title: "Uploaded File", detail: fileName)
                } else {
                    state = .error("Integrity check failed")
                }
                
            } catch {
                state = .error(error.localizedDescription)
            }
        }
    }
}
