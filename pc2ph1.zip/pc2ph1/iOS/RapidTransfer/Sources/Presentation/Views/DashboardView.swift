import SwiftUI

struct DashboardView: View {
    @StateObject var viewModel: TransferViewModel
    
    var body: some View {
        NavigationView {
            List {
                // Section 1: Status Panel
                Section {
                    HStack {
                        Image(systemName: "desktopcomputer")
                            .font(.largeTitle)
                            .foregroundColor(.blue)
                        
                        VStack(alignment: .leading) {
                            HStack {
                                Text("Desktop Agent")
                                    .font(.headline)
                                if let deviceName = viewModel.connectedDeviceName {
                                    Text("(\(deviceName))")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                            HStack {
                                Circle()
                                    .fill(Color.green) // Typically bind to viewModel.isOnline
                                    .frame(width: 8, height: 8)
                                Text("Online")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        Spacer()
                    }
                    .padding(.vertical, 4)
                } header: {
                    Text("Connection")
                }
                
                // Section 2: Active Transfer
                if case .transferring(let progress) = viewModel.state {
                    Section {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Downloading File...")
                                .font(.headline)
                            
                            ProgressView(value: progress)
                                .progressViewStyle(LinearProgressViewStyle())
                            
                            HStack {
                                Text("\(Int(progress * 100))%")
                                Spacer()
                                // Placeholder for MB/MB calculation
                                Text("-- MB / -- MB")
                            }
                            .font(.caption)
                            .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 8)
                    } header: {
                        Text("Active Transfer")
                    }
                }
                
                // Section 3: History (Rich Cards)
                Section {
                    if viewModel.history.isEmpty {
                        Text("No recent transfers")
                            .foregroundColor(.secondary)
                            .italic()
                    } else {
                        ForEach(viewModel.history) { item in
                            TransferCard(item: item)
                                .environmentObject(viewModel)
                        }
                        .onDelete { offsets in
                            viewModel.deleteHistory(at: offsets)
                        }
                    }
                } header: {
                    HStack {
                        Text("History")
                        Spacer()
                        if !viewModel.history.isEmpty {
                            Button("Clear All") {
                                viewModel.clearHistory()
                            }
                            .font(.caption)
                            .foregroundColor(.red)
                        }
                    }
                }
            }
            .navigationTitle("Transfer. Easily.")
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Antigravity")
            .listStyle(InsetGroupedListStyle())
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                     Button(action: {
                         showConnectionSheet = true
                     }) {
                         Image(systemName: "network")
                     }
                 }
            }
            .sheet(isPresented: $showConnectionSheet) {
                NavigationView {
                    List {
                        Section(header: Text("Discovered Devices")) {
                            if viewModel.discoveredServers.isEmpty {
                                Text("Searching...")
                                    .foregroundColor(.secondary)
                                    .italic()
                            } else {
                                ForEach(viewModel.discoveredServers, id: \.self) { server in
                                    Button(action: {
                                        viewModel.connectTo(serverName: server)
                                        showConnectionSheet = false
                                    }) {
                                        HStack {
                                            Image(systemName: "desktopcomputer")
                                            Text(server)
                                            Spacer()
                                            if viewModel.connectedDeviceName == server {
                                                Image(systemName: "checkmark")
                                                    .foregroundColor(.blue)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        Section(header: Text("Manual Connection")) {
                            TextField("Enter IP (e.g. 192.168.1.5)", text: $inputIP)
                                .keyboardType(.numbersAndPunctuation)
                            Button("Connect to IP") {
                                if let url = URL(string: "http://\(inputIP):8080") {
                                    viewModel.connectManually(url: url)
                                    showConnectionSheet = false
                                }
                            }
                        }
                    }
                    .navigationTitle("Connect")
                    .toolbar {
                        Button("Close") { showConnectionSheet = false }
                    }
                }
            }
        }
    }
    
    @State private var showConnectionSheet = false
    @State private var inputIP = ""

struct TransferCard: View {
    let item: TransferViewModel.HistoryItem
    @EnvironmentObject var viewModel: TransferViewModel // Need viewmodel for action
    @State private var justCopied = false
    
    var isFile: Bool {
        item.type == .file
    }
    
    var body: some View {
        HStack(spacing: 15) {
            ZStack {
                Circle()
                    .fill(isFile ? Color.orange.opacity(0.1) : Color.blue.opacity(0.1))
                    .frame(width: 40, height: 40)
                
                Image(systemName: isFile ? "doc.fill" : "text.quote")
                    .foregroundColor(isFile ? .orange : .blue)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Text(item.detail)
                    .font(.caption)
                    .lineLimit(2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            if !isFile {
                Button(action: {
                    UIPasteboard.general.string = item.detail
                    withAnimation {
                        justCopied = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        justCopied = false
                    }
                }) {
                    Image(systemName: justCopied ? "checkmark" : "doc.on.doc")
                        .foregroundColor(justCopied ? .green : .blue)
                }
                .buttonStyle(BorderlessButtonStyle())
            } else {
                Button(action: {
                    viewModel.downloadHistoryItem(item)
                }) {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.title2)
                        .foregroundColor(.green)
                }
                .buttonStyle(BorderlessButtonStyle())
            }
        }
        .padding(.vertical, 4)
    }
}
