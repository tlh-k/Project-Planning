import Foundation

enum TransferType: String, Codable {
    case text
    case file
}

struct TransferModel: Identifiable, Codable {
    let id: UUID
    let type: TransferType
    let timestamp: TimeInterval
    
    // Optional fields depending on type
    var textPayload: TextPayload?
    var filePayload: FilePayload?
}

struct TextPayload: Codable {
    let content: String
    let isAutoCopy: Bool
}

struct FilePayload: Codable {
    let fileName: String
    let fileExtension: String
    let mimeType: String
    let size: Int64
    let hash: String // SHA-256
    let downloadUrl: String?
}

// Responses from API
struct TransferInitResponse: Codable {
    let transferId: String
    let approved: Bool
    let maxChunkSize: Int
    
    enum CodingKeys: String, CodingKey {
        case transferId = "transfer_id"
        case approved
        case maxChunkSize = "max_chunk_size"
    }
}
