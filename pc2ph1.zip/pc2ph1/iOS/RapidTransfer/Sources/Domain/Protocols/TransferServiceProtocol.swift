import Foundation
import Combine

protocol TransferServiceProtocol {
    /// Checks server availability and returns device name
    func fetchServerStatus() async throws -> String
    
    /// Initiates a file transfer (Pre-flight)
    func initTransfer(fileName: String, size: Int64, mimeType: String, hash: String) async throws -> String
    
    /// Uploads a single chunk or full file
    func uploadData(transferId: String, data: Data, isLastChunk: Bool) async throws
    
    /// Finalizes the transfer for hash verification
    func finalizeTransfer(transferId: String) async throws -> Bool
    
    /// Sends a text payload
    func sendText(content: String, isAutoCopy: Bool) async throws
}
