# Antigravity Sync: Setup & Walkthrough

## 1. Setup Guide (Desktop Agent)

### Prerequisites
- Python 3.9+ installed on your PC/Linux/Mac.
- `pip` package manager.

### Installation
1. Navigate to the server directory:
   ```bash
   cd ~/Documents/Antigravity/pc2ph1/Server/Python
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### Running the Server
Start the agent in **Server Mode** (Foreground):
```bash
python agent.py
```
> The server will start on port `8080`, register itself via mDNS, and listen for incoming connections from iOS.

---

## 2. Integration Test (via Curl)

While the server is running, open a new terminal tab to simulate the iOS client.

### A. Test Handshake
Verify server is online and accepting pairing:
```bash
curl -X GET "http://localhost:8080/handshake?device_id=test-cli-client"
```
**Expected Output:** `{"status": "paired", "token": "..."}`

### B. Test File Transfer (Simulated Flow)
An "upload" happens in 3 steps: `init` -> `upload` -> `finalize`. We will upload a small string "Hello World" as if it were a file.

**Step 1: Init (Pre-flight)**
Get a Transfer ID. We declare a file named `test.txt` with size 11 bytes. *Hash for "Hello World" is `a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e`.*
```bash
# Save response to a var or just copy the transfer_id manually
curl -X POST "http://localhost:8080/transfer/init" \
     -H "Content-Type: application/json" \
     -d '{
       "fileName": "test.txt",
       "size": 11,
       "mimeType": "text/plain",
       "hash": "a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e"
     }'
```
**Expected:** `{"transfer_id": "UUID...", ...}`

**Step 2: Upload (Binary)**
Replace `YOUR_ID` with the ID from Step 1.
```bash
curl -X PUT "http://localhost:8080/transfer/upload/YOUR_ID" \
     -H "Content-Type: application/octet-stream" \
     --data "Hello World"
```
**Expected:** `{"status": "chunk_received"}`

**Step 3: Finalize (Verification)**
```bash
curl -X POST "http://localhost:8080/transfer/finalize/YOUR_ID"
```
**Expected:** `{"status": "completed", "path": ".../received_files/test.txt"}`

*(Process Check: Check the `received_files` folder; `test.txt` should appear there.)*

---

## 3. Phase 3: Deploying to iPhone (Critical)

Since you are developing on **Linux**, you cannot directly run the iOS application from here. You must follow these steps:

1.  **Transfer Source Code:** verify
    Copy the `iOS/` folder from this computer to a **Mac (MacBook / Mac mini)**.
    *(You can use a USB drive, Git, or cloud storage).*

2.  **Open in Xcode:**
    On the Mac, open `iOS/RapidTransfer/Sources/App/RapidTransferApp.swift` (or the project file if generated) using **Xcode**.
    *Note: You may need to create a new Xcode Project and drag the `Sources` folder into it since we only created the source files on Linux.*

3.  **Build & Run:**
    - Connect your iPhone to the Mac via cable.
    - Select your iPhone as the "run destination" in Xcode.
    - Press **Run** (Play button).

4.  **Syncing (Usage):**
    - Ensure your iPhone and this PC (running `agent.py`) are on the **SAME Wi-Fi network**.
    - Open the app on iPhone.
    - Look for the **Green Dot** (Online) in the Dashboard.
    - **Metin Gönderme:** PC'de bir şey kopyalayın -> Telefondaki listeye anında düşer.
    - **Dosya Gönderme:** PC'de terminalden `python agent.py` çalışırken özel komutlar veya ileride eklenecek, UI ile dosya seçebilirsiniz.

---

## 4. Detailed Xcode Guide (Mac Steps)

Since we created bare source files on Linux, you need to create the Project structure on Mac.

### Step 1: Create Project
1. Open **Xcode** -> **Create a new Xcode project**.
2. Select **iOS** -> **App**.
3. Product Name: `RapidTransfer`.
4. Interface: **SwiftUI**. Language: **Swift**.
5. Save it anywhere (e.g., Desktop).

### Step 2: Import Code
1. In the Xcode Project Navigator (left sidebar), delete the default `RapidTransferApp.swift` and `ContentView.swift`.
2. Drag and drop the `Sources` folder (from your Linux transfer) into the "RapidTransfer" folder in Xcode.
3. In the dialog:
   - Check **"Copy items if needed"**.
   - Check **"Create groups"**.
   - Ensure the "RapidTransfer" target is selected.
   - Click **Finish**.

### Step 3: Configure Permissions (CRITICAL)
For the app to find the PC, you must declare Local Network usage.
1. Click the **Project File** (blue icon at root).
2. Select the **Target** (RapidTransfer) -> **Info** tab.
3. **Add a New Key:**
   - Hover over any existing key (like "Bundle name") and click the **(+) Plus button** that appears.
   - Or right-click on the list and select **"Add Row"**.
4. Type/Select Key: **"Privacy - Local Network Usage Description"**.
   - Value: "Required to find Antigravity Server."
5. Add another Key: **"Bonjour services"**.
   - Change the Type to **Array**.
   - Click the arrow `>` to expand the array.
   - Click the `+` inside to add Item 0.
   - Value for Item 0: `_antigrav._tcp`

### Step 4: Run on Device
1. Connect iPhone via USB.
2. Select your iPhone in the top toolbar (Product Destination).
3. **Signing:** Go to **Signing & Capabilities** tab. Add your Apple ID as a "Team".
4. Press **Cmd+R** or the Play button.
   - *If it says "Untrusted Developer":* On iPhone, go to **Settings > General > VPN & Device Management**, tap your email, and "Trust".

---

## 5. SDD Validation Checklist

| Requirement | Implementation | Status |
| :--- | :--- | :--- |
| **Pre-flight Check** | `POST /transfer/init` checks metadata before bytes flow. | ✅ Pass |
| **Chunked Transfer** | `PUT` endpoint accepts streams (Python-multipart/Uvicorn streaming). | ✅ Pass |
| **Hash Verification** | Server calculates SHA256 of `temp_file` on finalize. Matches `init` claim. | ✅ Pass |
| **Clean Architecture** | iOS Code separated into Domain/Data/Presentation layers. | ✅ Pass |
| **mDNS Discovery** | `zeroconf` used on Py, `_antigravity-sync._tcp` advertised. | ✅ Pass |

---

## 4. Future-Proofing Tips

### GUI & System Tray
To convert this script into a background menu-bar application:

*   **Option A: Pystray (Recommended for Minimalism)**
    *   **Why:** Extremely lightweight. Perfect for just having an icon that says "Quit" or "Show QR".
    *   **Stack:** `pystray` + `Pillow`.
    *   **Code Snippet:**
    ```python
    import pystray
    from PIL import Image
    
    def on_quit(icon):
        icon.stop()
        server_process.terminate()

    icon = pystray.Icon("AntiSync", Image.open("icon.png"), "Antigravity", menu=...)
    icon.run()
    ```

*   **Option B: PySide6 (Qt for Python)**
    *   **Why:** If you plan to add a detailed Settings window, File History UI, or complex Pairing wizard.
    *   **Trade-off:** Much larger binary size (Qt libs).

### Cloud Extension
The `TransportProvider` interface in iOS is ready. You would simply implement an `aws_lambda_agent.py` that mimics these `POST` endpoints but saves to S3.
