# API Contract & Data Specification: rapid-transfer-ios

**Version:** 1.1.0
**Date:** 2026-02-06
**Standard:** OpenAPI 3.1 / JSON Schema
**Scope:** Interface between Desktop Agent (Server) and iOS Client.

> [!NOTE]
> **Directionality:**
> This API defines the endpoints hosted by the **Desktop Agent**.
> *   **iOS -> Desktop:** Client calls these `POST` endpoints.
> *   **Desktop -> iOS:** Server sends "File Available" WebSocket event; Client initiates `GET` download and performs local hash verification.

---

## 1. Network Discovery (Zero Configuration)

- **Protocol:** mDNS (Bonjour / Avahi)
- **Service Type:** `_antigrav._tcp`
- **Port:** Dynamic (Default: `8080`).

---

## 2. API Endpoints (OpenAPI Spec)

```yaml
openapi: 3.1.0
info:
  title: Antigravity Sync API
  version: 1.1.0
servers:
  - url: http://{server_ip}:{port}
    variables:
      server_ip:
        default: localhost
      port:
        default: "8080"

paths:
  # --- System ---
  /status:
    get:
      summary: Heartbeat & Device Info
      responses:
        '200':
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/StatusResponse'

  /handshake:
    get:
      summary: Initiate Pairing
      parameters:
        - in: query 
          name: device_id 
          required: true 
          schema: { type: string }
      responses:
        '200':
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HandshakeResponse'

  # --- Data Transfer Flow (iOS -> PC) ---
  
  /transfer/init:
    post:
      summary: Pre-flight Check (Start Upload)
      description: |
        Step 1: Client sends file metadata.
        Server verifies disk space/permissions and returns a Transfer Token.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TransferInitRequest'
      responses:
        '200':
          description: Transfer approved.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TransferInitResponse'
        '409':
          description: File already exists / Duplicate transfer.
        '413':
          description: File too large.

  /transfer/upload/{transfer_id}:
    put:
      summary: Binary Data Upload
      description: |
        Step 2: Upload request.
        * For < 50MB: Standard body.
        * For > 50MB: Use 'Transfer-Encoding: chunked' OR 'multipart/form-data'.
      parameters:
        - in: path
          name: transfer_id
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/octet-stream:
            schema:
              type: string
              format: binary
          multipart/form-data:
            schema:
              type: object
              properties:
                file:
                  type: string
                  format: binary
      responses:
        '200':
          description: Chunk/File accepted.

  /transfer/finalize/{transfer_id}:
    post:
      summary: Hash Verification & Completion
      description: |
        Step 3: Client signals end of transfer.
        Server calculates SHA-256 of received bytes.
        If hash matches 'init' metadata -> 200 OK.
        Else -> 400 Bad Request (Corruption).
      parameters:
        - in: path
          name: transfer_id
          required: true
          schema: { type: string }
      responses:
        '200':
          description: Hash verified. File saved.
        '400':
          description: Hash mismatch.

  # --- Simple Text Transfer ---
  /transfer/text:
    post:
      summary: Send Clipboard/Text
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TextPayload'
      responses:
        '201':
          description: Text saved/copied.

components:
  schemas:
    # --- System Schemas ---
    StatusResponse:
      type: object
      properties:
        online: { type: boolean }
        device_name: { type: string }
        
    HandshakeResponse:
      type: object
      properties:
        status: { type: string, enum: ["paired", "challenge_required"] }
        token: { type: string }

    # --- Transfer Schemas ---
    TransferInitRequest:
      type: object
      required: [fileName, size, mimeType, hash]
      properties:
        fileName: { type: string }
        size: { type: integer }
        mimeType: { type: string }
        hash: { type: string, description: "SHA-256 checksum of source file." }

    TransferInitResponse:
      type: object
      properties:
        transfer_id: { type: string }
        approved: { type: boolean }
        max_chunk_size: { type: integer, default: 10485760 }

    TextPayload:
      type: object
      required: [content]
      properties:
        content: { type: string }
        isAutoCopy: { type: boolean, default: true }

```

---

## 3. Transfer Rules

### 3.1 Large File Handling (> 50MB)
1.  **Chunked Encoding**: Preferred. The client streams the body using `Transfer-Encoding: chunked`.
2.  **Multipart**: Alternative. Standard `multipart/form-data`.
3.  **Resumability**: (Future) `Range` headers can be supported on the `PUT` endpoint.

### 3.2 Pre-flight & Verification Flow
1.  **Init**: Client POSTs metadata to `/transfer/init`. Server validates and returns `transfer_id`.
2.  **Upload**: Client sends bytes to `/transfer/upload/{id}`.
3.  **Finalize**: Client POSTs to `/transfer/finalize/{id}`.
    - Server computes SHA-256 of the temp file on disk.
    - Server compares with the `hash` provided in Step 1.
    - **Match:** Move file to final destination. Return `200 OK`.
    - **Mismatch:** Delete temp file. Return `400 Bad Request` "Integrity Check Failed".

---
