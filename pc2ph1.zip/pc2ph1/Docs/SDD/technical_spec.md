# Technical Specification: rapid-transfer-ios

**Version:** 1.1.0
**Status:** Draft (Revision 1)
**Date:** 2026-02-06
**Author:** Antigravity

---

## 1. System Architecture: The "Link" Concept

The system is designed as a **Transport-Agnostic Data Synchronization Link**. While the initial implementation focuses on Local LAN, the architecture abstracts the communication layer to treat "Local" and "Cloud" as interchangeable transport providers.

### 1.1 Components
- **Desktop Agent (Source/Peer):** A cross-platform service running on **Linux, Windows, or macOS**.
    - *Tech Stack:* Go (Golang) or Node.js recommended for native cross-platform networking and binary distribution.
- **Mobile Client (Receiver/Peer):** iOS Application.
    - *Architecture:* Built around a `TransferEngine` that orchestrates data flow regardless of the source.

### 1.2 The Transport Abstraction Protocols (Core Design)
The application will not directly call WebSocket or HTTP logic in its view layers. Instead, it will use a `TransportProvider` interface.

```swift
protocol TransportProvider {
    var providerType: TransportType { get } // .local, .cloud
    var connectionState: AnyPublisher<ConnectionState, Never> { get }
    
    func connect()
    func disconnect()
    func send(payload: DataPayload) async throws
}

protocol TransportDelegate: AnyObject {
    func didReceive(payload: DataPayload, from provider: TransportProvider)
}
```

#### Implementation A: `LocalLANTransport`
- **Discovery:** Bonjour/mDNS (`_rapidtransfer._tcp`).
- **Control Channel:** Secure WebSocket (WSS).
- **Data Channel:** HTTPS.
- **Priority:** High (Preferred when available due to speed and cost).

#### Implementation B: `CloudTransport` (Planned)
- **Discovery:** User Login / Device ID Pairing.
- **Control Channel:** FCM/APNS (Push Notifications) or MQTT.
- **Data Channel:** AWS S3 / Firebase Storage signed URLs.
- **Priority:** Fallback (Used when Local LAN is unavailable).

---

## 2. Desktop Agent (Linux / Windows / macOS)

The desktop side must be portable.
- **Language:** Go (Golang) is proposed for its single-binary distribution, excellent cross-platform networking (net/http), and low resource footprint on Linux servers/desktops.
- **GUI:** Minimal system tray icon (using libraries like `systray` or `program`) to manage status.
- **FilesystemWatcher:** Uses native OS APIs (inotify on Linux, FSEvents on Mac, ReadDirectoryChangesW on Windows) to auto-send files if a specific folder is watched.

---

## 3. Data Transfer Protocol & Model

### 3.1 Unified Payload Structure
Using a unified JSON schema ensures the iOS client processes data exactly the same way, whether it came from a Local WebSocket or a Cloud Database update.

```json
{
  "id": "uuid-v4",
  "source_device_id": "desktop-linux-01",
  "target_device_id": "iphone-15-pro",
  "type": "text" | "file_pointer",
  "timestamp": 1678900000,
  "encrypted": true, // Future-proofing
  "payload": { ... } 
}
```

### 3.2 File Handling (The "Pointer" approach)
Files are never sent inline. The payload contains a "pointer" (URL).
- **Local Context:** URL references the Desktop's local IP (e.g., `https://192.168.1.5:8080/files/doc.pdf`).
- **Cloud Context:** URL references a cloud storage object (e.g., `https://s3.amazonaws.com/bucket/doc.pdf`).

The iOS `DownloadManager` accepts this URL and handles the transfer, oblivious to whether it's pulling from a local neighbor or a remote server.

---

## 4. Security Protocol

### 4.1 Hybrid Security Strategy
- **Local:** TLS 1.3 with Self-Signed Certificates (generated on first launch by the Desktop Agent).
- **Cloud:** Standard HTTPS/SSL (managed by cloud provider).
- **End-to-End Encryption (E2EE):** (Future) Payloads can be encrypted/decrypted using a shared secret generated during pairing, ensuring even the Cloud Provider cannot read the clipboard contents.

### 4.2 Universal Pairing Flow
1. **Desktop:** Generates a QR Code containing:
   - Device ID
   - Public Key (for E2EE)
   - Local IP addresses (hints)
   - Pairing Secret / PIN
2. **iOS:** Scans QR Code.
3. **Storage:** iOS saves this identity into the **Device Registry**.
   - *Result:* The iOS app now "knows" this Desktop. It effectively listens for it on Local LAN (via mDNS matching the Device ID) AND checks the Cloud (if enabled) for messages from this ID.

---

## 5. iOS Specifics & Background Strategy

### 5.1 Background Handling
- **Local:** `BGProcessingTask` is used for large file transfers initiated in the foreground.
- **Cloud:** `Remote Notifications` (APNs) are essential here. A "content-available: 1" silent push can wake the app to process clipboard text or small files even when the app is killed (subject to iOS budgeting).

---
